# Cartoon 3D Short Plugin

Antigravity plugin wrapping [mromidev/claude-animated-shorts](https://github.com/mromidev/claude-animated-shorts) (`cartoon-3d-short`).

## Included

- **Skill**: `cartoon-3d-short` (`skills/cartoon-3d-short/SKILL.md`), plus `templates/` (`bridge/`, `audio/`, `scripts/`) and `references/` (`STYLE_BIBLE.md`, `reports/`, `frames/`, `sheets/`).
