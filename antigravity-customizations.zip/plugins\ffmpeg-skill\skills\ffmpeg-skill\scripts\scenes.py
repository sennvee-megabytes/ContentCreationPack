#!/usr/bin/env python3
"""Find scene changes and loud moments, and propose highlight candidates so the
agent can plan an edit or a digest without watching the whole file.

Scene cuts come from ffmpeg's scdet; energy peaks from a 0.5 s RMS envelope
of the audio. Highlight candidates are scenes ranked by --rank-by: "audio"
(default, loudest first) or "duration" (longest first). Both are proxies,
not a judgement of what matters: "audio" misses a quiet but important
moment (a confession, a punchline landing in silence) and can surface pure
crowd noise; "duration" just finds long unbroken takes. Neither replaces
watching the contact sheet (--sheet) before committing to a cut.

Examples:
  python3 scenes.py talk.mp4                                # scenes + peaks, JSON
  python3 scenes.py event.mp4 --highlights 5 --target 60   # 5 candidate ranges summing to ~60 s
  python3 scenes.py event.mp4 --highlights 4 --edl picks.txt   # cut.py --segments compatible list
  python3 scenes.py event.mp4 --sheet scenes.png             # one thumbnail per scene
  python3 scenes.py talk.mp4 --highlights 5 --rank-by duration  # longest unbroken scenes, not loudest
"""
import argparse
import math
import sys
from typing import Dict, List, Optional, Tuple

# `detect_scenes` moved into _common/probe.py in 1.16.0 (see silence.py); the body is unchanged.
from _common import (guard_sidecar, detect_scenes, STATE, add_common, apply_common, beat_grid, default_font_file, die, emit,
                     ffmpeg_base, info, print_json, probe, run, decode_pcm_mono,
                     rms_envelope, BEAT_MIN_CONFIDENCE, decode_gray_frames, frame_flow, label_shot_flow)
from _common import drawtext_fontfile  # noqa: E402
from _common import ffmpeg_filters, filter_missing_hint  # noqa: E402
from _common.emit import note, record_fallback  # noqa: E402
from _common.color import bt709_label_filter  # noqa: E402
from _common.probe import PROBED_VIDEO, square_pixels  # noqa: E402
from _common import dry_run_input_pending  # noqa: E402
from _common.emit import input_length  # noqa: E402

SHOT_FPS = 4.0          # frames/second sampled for --shots' flow estimate
SHOT_W, SHOT_H = 48, 27  # decode size for --shots (16:9-ish; enough blocks, still a few KB/shot)
SPEECH_STEP_S = 1.0      # --speech energy-ratio window



def audio_envelope(path: str, step_s: float, *, rate: int = 8000,
                   samples: "Optional[List[float]]" = None) -> List[float]:
    """RMS level per step_s window, absolute (a loud scene scores higher); [] when the audio
    cannot be decoded (the cut scoring then runs on the picture alone).

    `samples` reuses PCM a caller already decoded rather than decoding the same file twice --
    --beats needs a 10 ms envelope and the scene scoring a 0.5 s one, and 0.5 s is an integer
    multiple of 10 ms, so both come from one pass.
    """
    if samples is None:
        samples = decode_pcm_mono(path, rate, check=False)
    return rms_envelope(samples, int(rate * step_s))


def parse_beat_range(text: str) -> "tuple":
    """`--beat-range 60-200` as (lo, hi) BPM."""
    try:
        lo, hi = (float(p) for p in str(text).replace(" ", "").split("-", 1))
    except ValueError:
        die(f"--beat-range: expected LO-HI in BPM (e.g. 60-200), got {text!r}", kind="input")
    if not (0 < lo < hi):
        die(f"--beat-range {text}: LO must be above 0 and below HI", kind="input")
    return (lo, hi)


def shot_flow_label(path: str, start: float, end: float) -> Dict:
    """{start, end, label, flow_magnitude} for one shot: decode it at SHOT_FPS/SHOT_W x SHOT_H
    and block-match consecutive frames (see _common.decision.frame_flow / label_shot_flow). A
    shot under two sampled frames has nothing to compare and is reported static with
    flow_magnitude 0 -- there is no motion measurement to make on a single frame."""
    frames = decode_gray_frames(path, SHOT_FPS, SHOT_W, SHOT_H, start=start, seconds=max(0.0, end - start), check=False)
    flows = [frame_flow(frames[i], frames[i + 1], SHOT_W, SHOT_H) for i in range(len(frames) - 1)]
    label = label_shot_flow(flows)
    return {"start": round(start, 3), "end": round(end, 3), "label": label["label"], "flow_magnitude": label["flow_magnitude"]}


def audio_peaks_db(samples: "List[float]", rate: int, step_s: float = 0.25) -> List[Dict]:
    """--audio-peaks: local maxima of the loudness envelope reported as measured dBFS, not the
    unitless RMS scenes.py has always put in the (unconditional) `audio_peaks` key -- a
    different unit needs a different key so the existing one keeps meaning what it always has."""
    env = rms_envelope(samples, int(rate * step_s))
    peaks = []
    for i, val in enumerate(env):
        if val <= 1e-6:
            continue
        if (i == 0 or env[i - 1] <= val) and (i == len(env) - 1 or env[i + 1] <= val):
            level = round(20 * math.log10(val), 1)
            peaks.append({"time": round(i * step_s, 2), "level": level})
    return peaks


def speech_music_ratio(samples: "List[float]", rate: int, step_s: float = SPEECH_STEP_S) -> List[Dict]:
    """--speech: a per-second zero-crossing-rate ratio, reported as a measured number, not a
    speech/music label. Speech's rapid consonant transients drive the zero-crossing rate up and
    make it jump window to window; sustained tones (music, a held note, room tone) cross zero at
    a steadier rate. ratio = this window's ZCR / the file's median ZCR, so 1.0 is "typical for
    this file" regardless of its overall noisiness -- a proxy, in the same spirit as scenes.py's
    --rank-by, not a classifier: nothing here decides what is speech."""
    step = max(1, int(rate * step_s))
    zcrs: List[float] = []
    for i in range(0, len(samples) - step + 1, step):
        block = samples[i:i + step]
        crossings = sum(1 for a, b in zip(block, block[1:]) if (a >= 0) != (b >= 0))
        zcrs.append(crossings / max(1, len(block) - 1))
    if not zcrs:
        return []
    med = sorted(zcrs)[len(zcrs) // 2] or 1e-9
    return [{"time": round(i * step_s, 2), "speech_music_ratio": round(z / med, 3)} for i, z in enumerate(zcrs)]


# A --sheet picks one frame a scene with select. One expression summing a term a scene was refused
# by FFmpeg 7.1 and later at 3,000 scenes ("Error while parsing expression", ENOMEM) and taken by
# 6.1. No expression here grows with the scene count: the scenes are dealt round-robin to branches
# of at most SHEET_SELECT_TERMS terms, each summed as a balanced tree (at most
# ceil(log2(SHEET_SELECT_TERMS)) = 6 nested parentheses), and the branches' frames are merged back in
# time order by interleave. Round-robin keeps the branches level, so interleave holds about one
# thumbnail a branch.
SHEET_SELECT_TERMS = 64


def _first_at(t: float) -> str:
    """The select term for the first frame at or after `t`. The starts are presentation times, so
    the frame is chosen by its time, not by start x fps as a frame number -- on a
    variable-frame-rate source that number is another frame (#411)."""
    a = f"{max(0.0, t - 0.0006):.4f}"
    return f"gte(t\\,{a})*(isnan(prev_t)+lt(prev_t\\,{a}))"


def _balanced_sum(terms: List[str]) -> str:
    if len(terms) == 1:
        return terms[0]
    mid = len(terms) // 2
    return f"({_balanced_sum(terms[:mid])}+{_balanced_sum(terms[mid:])})"


def sheet_graph(starts: List[float], src: str, thumb: str, tile: str) -> str:
    """The --sheet filter graph: exactly one frame a scene (the first at or after its start), each
    made a thumbnail by `thumb`, laid out by `tile`, out as [sheet]."""
    # no scene (a dry run whose input an earlier step has yet to write, a clip of under one scene):
    # the sheet is its one tile, the first frame, as the 1x1 layout the caller sized for it
    starts = starts or [0.0]
    k = max(1, math.ceil(len(starts) / SHEET_SELECT_TERMS))
    if k == 1:
        return f"{src}select='{_balanced_sum([_first_at(t) for t in starts])}',{thumb},{tile}[sheet]"
    parts = [f"{src}split={k}" + "".join(f"[s{j}]" for j in range(k))]
    for j in range(k):
        expr = _balanced_sum([_first_at(t) for t in starts[j::k]])
        parts.append(f"[s{j}]select='{expr}',{thumb}[t{j}]")
    parts.append("".join(f"[t{j}]" for j in range(k)) + f"interleave=nb_inputs={k},{tile}[sheet]")
    return ";".join(parts)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input")
    ap.add_argument("--threshold", type=float, default=8.0, help="minimum scdet score for a cut, 0-100 (default 8)")
    ap.add_argument("--ratio", type=float, default=3.0, help="a cut must exceed this multiple of the neighbouring frames' median score (default 3; lower = more cuts)")
    ap.add_argument("--min-scene", type=float, default=1.0, help="ignore cuts closer than this in seconds (default 1)")
    ap.add_argument("--highlights", type=int, default=0, help="number of highlight ranges to propose")
    ap.add_argument("--rank-by", choices=["audio", "duration"], default="audio",
                    help="how to rank scenes for --highlights: audio energy (default) or scene duration")
    ap.add_argument("--target", type=float, help="with --highlights: total seconds the picks should add up to (trims long scenes)")
    ap.add_argument("--max-scene", type=float, default=15.0, help="cap a highlight range at this many seconds (default 15)")
    ap.add_argument("--edl", help="write highlight ranges as START-END lines (cut.py --segments format)")
    ap.add_argument("--beats", action="store_true",
                    help="measure the music's beat grid (tempo, beat times, confidence) and report it; "
                         "a measurement, not a proposal -- no cut is made and no beat is invented")
    ap.add_argument("--beat-step", type=float, default=0.01,
                    help="envelope resolution in seconds for the onset pass with --beats (default 0.01)")
    ap.add_argument("--beat-range", default="60-200",
                    help="tempo search range in BPM for --beats (default 60-200)")
    ap.add_argument("--min-confidence", type=float, default=BEAT_MIN_CONFIDENCE,
                    help="with --beats: below this confidence the grid is still reported, marked "
                         f"usable: false (default {BEAT_MIN_CONFIDENCE})")
    ap.add_argument("--shots", action="store_true",
                    help="label each detected shot static / pan / motion by a measured optical-flow "
                         "proxy (lightweight block matching over sampled frames); reports flow_magnitude too")
    ap.add_argument("--audio-peaks", action="store_true",
                    help="report loudness peaks as {time, level} in measured dBFS (separate from the "
                         "always-on `audio_peaks` RMS list used to pick --highlights)")
    ap.add_argument("--speech", action="store_true",
                    help="report a per-second speech-vs-music energy ratio (zero-crossing-rate proxy, "
                         "a measurement, not a speech/music classification)")
    ap.add_argument("--sheet", help="write a contact sheet PNG with the first frame of every scene")
    ap.add_argument("--no-timecode", action="store_true", help="--sheet without the burnt-in timecode stamp (a way out if drawtext itself is unusable, see doctor)")
    add_common(ap)
    args = ap.parse_args()
    apply_common(args)
    if args.highlights < 0:
        die(f"--highlights must be 0 or more (the number of ranges to propose), got {args.highlights}")
    if not args.highlights:
        # A145: these shape or write the --highlights picks; without it they were accepted and
        # nothing was written (--edl FILE completed with no file)
        for flag, given in (("--edl", args.edl is not None), ("--target", args.target is not None),
                            ("--max-scene", args.max_scene != ap.get_default("max_scene"))):
            if given:
                die(f"{flag} applies to the ranges --highlights proposes, and --highlights was not given; "
                    "add --highlights N")
    if args.target is not None and args.target <= 0:
        die(f"--target must be more than 0 seconds, got {args.target:g}")
    if args.max_scene <= 0:
        die(f"--max-scene must be more than 0 seconds, got {args.max_scene:g}")
    if args.highlights:  # the EDL is written only with --highlights
        guard_sidecar(args.edl, args.input, siblings=(args.sheet,))

    meta = probe(args.input)
    # Under --dry-run in a render.py/batch.py plan the input may be an earlier stage's output that
    # was never written: every measurement is skipped (diagnostics.skipped measurement_input_pending)
    # and the document keeps its shape with nothing measured, as loudness.py/cut.py do -- not an
    # ffmpeg failure that stops the plan from being written.
    pending = dry_run_input_pending(args.input)
    # An audio-only file (WAV/FLAC/MP3 ...) is measured too (after 3.2.0): the beat grid, the loudness
    # peaks and the speech ratio are measurements of the sound, and a music bed is usually
    # delivered without a picture. It has no picture to cut, so it is one scene from 0 to its
    # duration -- the same answer a video with no cut in it gets -- and the result says
    # audio_only: true. What needs a picture (--sheet, --shots) is refused, not skipped.
    audio_only = not meta.get("video")
    if audio_only:
        if not meta.get("audio"):
            die("input has no video or audio stream")
        picture_flags = [f for f, on in (("--sheet", args.sheet), ("--shots", args.shots)) if on]
        if picture_flags:
            die(f"{' and '.join(picture_flags)} need{'s' if len(picture_flags) == 1 else ''} a video stream; "
                "this file is audio-only (input has no video stream). --beats, --audio-peaks, --speech "
                "and --highlights measure the sound alone.", kind="input")
    # Only parsed when it is going to be used: --beat-range is a --beats flag, and a run that
    # never asked for beats should not be able to die on one.
    beat_range = parse_beat_range(args.beat_range) if args.beats else (60.0, 200.0)
    if args.beats:
        if not meta.get("audio"):
            die("--beats needs an audio stream; this file has none", kind="input")
        if args.beat_step <= 0:
            die("--beat-step must be greater than 0", kind="input")
    dur = input_length(meta)
    cuts = [0.0] if (audio_only or pending) else detect_scenes(args.input, args.threshold, args.min_scene, dur, args.ratio)
    has_audio = bool(meta.get("audio")) and not pending
    bounds = cuts + [dur]
    step_s = 0.5
    # With --beats the file is decoded once, at the finer rate, and both envelopes come from that
    # one pass: the 0.5 s scene blocks are an exact multiple of the 10 ms onset blocks.
    beat_rate = 22050
    need_fine = args.beats or args.audio_peaks or args.speech
    # --beats decodes with check=True: a decode that fails is an ffmpeg failure, not an empty
    # envelope reported as "no steady pulse in this audio" (the scene scoring alone tolerates it
    # and runs on the picture)
    fine_samples = decode_pcm_mono(args.input, beat_rate, check=bool(args.beats)) if (need_fine and has_audio) else None
    if fine_samples is not None:
        env = audio_envelope(args.input, step_s, rate=beat_rate, samples=fine_samples)
    else:
        env = audio_envelope(args.input, step_s) if has_audio else []

    scenes = []
    for i in range(len(bounds) - 1):
        s, e = bounds[i], bounds[i + 1]
        if e - s <= 0.05:
            continue
        seg = env[int(s / step_s): max(int(s / step_s) + 1, int(e / step_s))] if env else []
        energy = (sum(seg) / len(seg)) if seg else 0.0
        peak = max(seg) if seg else 0.0
        scenes.append({"index": len(scenes), "start": round(s, 3), "end": round(e, 3), "duration": round(e - s, 3),
                       "audio_rms": round(energy, 4), "audio_peak": round(peak, 4)})
    peaks = []
    if env:
        thr = sorted(env)[int(len(env) * 0.9)] if len(env) > 10 else max(env)
        for i, val in enumerate(env):
            if val >= thr and val > 0.02 and (i == 0 or env[i - 1] < val) and (i == len(env) - 1 or env[i + 1] <= val):
                peaks.append({"time": round(i * step_s, 2), "rms": round(val, 4)})
        peaks = sorted(peaks, key=lambda p: -p["rms"])[:20]
        peaks.sort(key=lambda p: p["time"])

    result: Dict = {"file": args.input, "duration": round(dur, 3), "scene_count": len(scenes), "scenes": scenes, "audio_peaks": peaks}
    if audio_only:
        result["audio_only"] = True
    info(f"{len(scenes)} scenes, {len(peaks)} audio peaks over {dur:.1f}s")

    if args.shots:
        shots = [shot_flow_label(args.input, s, e) for s, e in zip(bounds[:-1], bounds[1:]) if e - s > 0.05]
        result["shots"] = shots
        counts = {}
        for sh in shots:
            counts[sh["label"]] = counts.get(sh["label"], 0) + 1
        info(f"--shots: {len(shots)} shots (" + ", ".join(f"{v} {k}" for k, v in sorted(counts.items())) + ")")

    if args.audio_peaks:
        if not has_audio:
            result["audio_peaks_db"] = []
            info("--audio-peaks: no audio stream, nothing to measure")
        else:
            db_samples = fine_samples if fine_samples is not None else decode_pcm_mono(args.input, 22050, check=False)
            result["audio_peaks_db"] = audio_peaks_db(db_samples, 22050 if fine_samples is not None else 22050)
            info(f"--audio-peaks: {len(result['audio_peaks_db'])} peaks")

    if args.speech:
        if not has_audio:
            result["speech"] = []
            info("--speech: no audio stream, nothing to measure")
        else:
            sp_samples = fine_samples if fine_samples is not None else decode_pcm_mono(args.input, 22050, check=False)
            result["speech"] = speech_music_ratio(sp_samples, 22050)
            info(f"--speech: {len(result['speech'])} one-second windows")

    if args.beats:
        # A beat grid is a measurement of the music's periodicity, not a statement about where a
        # cut belongs. scenes.py reports what it measured, including a low confidence: reporting a
        # weak measurement is honest, and only a tool that CHANGES a file refuses to act on one.
        # The envelope's real step is a whole number of samples: 220 / 22050 = 9.977 ms for the
        # default 10 ms. Timing the onsets as if it were 10 ms stretched every measured time by
        # 0.23 % -- 68 ms by the end of a 30 s track, the "40-60 ms off" a click track showed --
        # so the grid is timed (and step_s reported) at the step the envelope actually has.
        beat_block = max(1, round(beat_rate * args.beat_step))
        fine = rms_envelope(fine_samples or [], beat_block)
        grid = beat_grid(fine, beat_block / beat_rate, bpm_range=beat_range,
                         min_confidence=args.min_confidence, duration=dur,
                         pcm=fine_samples, pcm_rate=beat_rate)
        result["beats"] = grid["beats"]
        result["beat_grid"] = {
            # The regular grid AND the subset a measured onset supports. A tool that MOVES
            # something (cut.py --snap beats) may only use the subset; scenes.py reports both,
            # because here the regular grid is the measurement being made.
            "supported_beats": grid["supported_beats"],
            "tempo_bpm": grid["tempo_bpm"], "interval": grid["interval"],
            "confidence": grid["confidence"], "phase": grid["phase"],
            "onsets": len(grid["onsets"]), "supported": grid["supported"],
            "unsupported": grid["unsupported"], "method": grid["method"],
            "step_s": grid["step_s"], "range_bpm": grid["range_bpm"], "usable": grid["usable"],
            # after 3.2.0, additive: how each onset was timed below the envelope step
            # ("pcm-window-ratio": placed on the decoded samples; null: at the step)
            "onset_refinement": grid["onset_refinement"],
        }
        if pending:
            info("--beats: [dry-run] the input does not exist yet, nothing measured")
        elif grid["tempo_bpm"] is None:
            info(f"--beats: no steady pulse in this audio (confidence {grid['confidence']:.2f}) -- "
                 "speech, ambience or rubato has no tempo to measure")
        else:
            info(f"--beats: {grid['tempo_bpm']:.1f} BPM, {len(grid['beats'])} beats, confidence "
                 f"{grid['confidence']:.2f} ({grid['supported']} of {len(grid['beats'])} grid points "
                 f"have a measured onset)"
                 + ("" if grid["usable"] else f" -- below --min-confidence {args.min_confidence}, usable: false"))

    if args.highlights:
        if args.rank_by == "duration":
            rank_key = lambda sc: (-sc["duration"], sc["start"])
        else:
            rank_key = lambda sc: (-sc["audio_rms"], sc["start"])
        ranked = sorted(scenes, key=rank_key)[: args.highlights]
        picks: List[Tuple[float, float]] = []
        empty: List[Tuple[float, float]] = []
        budget = args.target if args.target else None
        per = (budget / max(1, len(ranked))) if budget else args.max_scene
        for sc in ranked:
            length = min(sc["duration"], per, args.max_scene)
            # take the loudest window inside the scene
            best_s = sc["start"]
            if env and length < sc["duration"]:
                best, best_s = -1.0, sc["start"]
                win = max(1, int(length / step_s))
                # A139: a window starts at the scene's start or on the step grid after it, and
                # ends inside the scene. The grid point at or before the start (floor) was a
                # candidate, so a pick opened up to one step (0.5 s) early, on the previous shot
                latest = sc["end"] - length
                starts = [sc["start"]] + [i * step_s for i in range(math.ceil(sc["start"] / step_s - 1e-9),
                                                                      math.floor(latest / step_s + 1e-9) + 1)
                                          if sc["start"] < i * step_s <= latest]
                for t in starts:
                    i = int(t / step_s + 1e-9)
                    val = sum(env[i:i + win])
                    if val > best:
                        best, best_s = val, t
            # to the hundredth the result and the EDL are written in, inward: a start of 3.333
            # written as 3.33 opened on the frame before the cut
            pick_s = math.ceil(best_s * 100 - 1e-6) / 100
            pick_e = math.floor(min(sc["end"], pick_s + length) * 100 + 1e-6) / 100
            if pick_e <= pick_s:
                # no hundredth fits inside it: written as 0.00-0.00 it was a range cut.py refuses
                empty.append((sc["start"], sc["end"]))
                continue
            picks.append((pick_s, pick_e))
        if empty and not picks:
            die(f"--highlights found no range of at least 0.01 s, the precision the ranges are written in "
                f"(each pick is at most {min(per, args.max_scene):g} s, or its scene is shorter)",
                kind="input", hint="raise --target (or drop it), or lower --highlights")
        for s, e in empty:
            note(f"--highlights: the scene {s:.3f}-{e:.3f}s holds no range of at least 0.01 s and has no pick")
        picks.sort()
        result["highlights"] = [{"start": s, "end": e, "duration": round(e - s, 2)} for s, e in picks]
        result["highlights_total"] = round(sum(e - s for s, e in picks), 2)
        result["highlights_rank_by"] = args.rank_by
        info(f"proposed {len(picks)} highlight ranges totalling {result['highlights_total']:.1f}s")

    if args.sheet:
        n = len(scenes)
        cols = min(4, max(1, n))
        rows = max(1, math.ceil(n / cols))
        tile_w = 1280 // cols // 2 * 2
        stamp = ""
        if not args.no_timecode and ffmpeg_filters() and "drawtext" not in ffmpeg_filters():
            # as look.py (#394): the sheet needs drawtext only for its stamps
            args.no_timecode = True
            record_fallback("this ffmpeg build has no drawtext filter, so the --sheet has no timecode stamps "
                            "(the same as --no-timecode)", "scenes_sheet_no_drawtext")
            note("--sheet without timecode stamps: this ffmpeg build has no drawtext filter ("
                 + filter_missing_hint("drawtext") + ")")
        if not args.no_timecode:
            default_font = default_font_file("DejaVu Sans")
            font_prefix = f"{drawtext_fontfile(default_font)}:" if default_font else ""
            stamp = f",drawtext=text='%{{pts\\:hms}}':{font_prefix}fontcolor=white:fontsize=h/14:box=1:boxcolor=black@0.55:boxborderw=4:x=6:y=6"
        # an untagged source is labelled BT.709 (tags only), or the sheet's RGB read it as BT.601 (#410);
        # a non-square-pixel source is squared at its display aspect (#411)
        lab = bt709_label_filter(meta)
        square = square_pixels(meta["video"])
        thumb = (lab + "," if lab else "") + (square + "," if square else "") + f"scale={tile_w}:-2{stamp}"
        graph = sheet_graph([sc["start"] for sc in scenes], f"[0:{PROBED_VIDEO}]", thumb,
                            f"tile={cols}x{rows}:padding=2:margin=2:color=0x202020")
        run(ffmpeg_base() + ["-i", args.input, "-filter_complex", graph, "-map", "[sheet]", "-an",
                             "-frames:v", "1", "-fps_mode", "vfr", "-update", "1", args.sheet])
        info(f"wrote {args.sheet}")
        result["sheet"] = args.sheet

    # after the sheet, as silence.py writes its EDL after the cut (#462 A41): a --sheet refused as an
    # existing file, or failed, left the EDL behind, and the corrected retry was then refused for it
    if args.highlights and args.edl:
        if not STATE.dry_run:  # the contract says --edl is not written under --dry-run
            with open(args.edl, "w", encoding="utf-8") as fh:
                for s, e in picks:
                    fh.write(f"{s:.2f}-{e:.2f}\n")
        info(f"wrote {args.edl}")

    if STATE.json:  # --json-brief too: emit() is what adds the diagnostics (scenes_sheet_no_drawtext)
        emit(None, **result)
    else:
        print_json(result)
    return 0


if __name__ == "__main__":
    sys.exit(main())
