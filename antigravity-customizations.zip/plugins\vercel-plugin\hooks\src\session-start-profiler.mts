/**
 * Session-start repo profiler hook.
 *
 * Scans the current working directory for common config files and package
 * dependencies, then persists likely skill slugs and greenfield state for the
 * active session. Claude Code keeps these session-scoped values in temp files,
 * while Cursor also emits JSON `{ env, additional_context }`.
 *
 * This pre-primes the skill matcher so the first tool call can skip
 * cold-scanning for obvious frameworks.
 */

import {
  accessSync,
  constants as fsConstants,
  existsSync,
  readFileSync,
  readdirSync,
  type Dirent,
} from "node:fs";
import { homedir } from "node:os";
import { delimiter, join, resolve } from "node:path";
import { execFileSync, execSync } from "node:child_process";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import type { AgentResult } from "detect-agent";
import {
  formatOutput,
  normalizeInput,
  setSessionEnv,
  type HookPlatform,
} from "./compat.mjs";
import { pluginRoot, safeReadJson, writeSessionFile } from "./hook-env.mjs";
import { createLogger, logCaughtError, type Logger } from "./logger.mjs";
import { hasSessionStartActivationMarkers } from "./session-start-activation.mjs";
import { buildSkillMap } from "./skill-map-frontmatter.mjs";
import {
  isDauTelemetryEnabled,
  refreshActiveSessionMarker,
  trackDauActiveToday,
  type AgentHarness,
} from "./telemetry.mjs";
import { writeSessionAgentHarness } from "./skill-telemetry.mjs";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface FileMarker {
  file: string;
  skills: string[];
}

interface PackageJson {
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
  scripts?: Record<string, unknown>;
  [key: string]: unknown;
}

interface BootstrapSignals {
  bootstrapHints: string[];
  resourceHints: string[];
  setupMode: boolean;
}

interface GreenfieldResult {
  entries: string[];
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/**
 * Mapping from marker file / condition to skill slugs.
 */
const FILE_MARKERS: FileMarker[] = [
  { file: ".eve", skills: ["eve"] },
  { file: "vercel.json", skills: ["vercel-cli", "deployments-cicd", "vercel-functions"] },
  { file: "middleware.ts", skills: ["routing-middleware"] },
  { file: "middleware.js", skills: ["routing-middleware"] },
  { file: "flags.ts", skills: ["flags-sdk"] },
  { file: ".env.local", skills: ["env-vars"] },
];

/**
 * Dependency names in package.json -> skill slugs.
 */
const PACKAGE_MARKERS: Record<string, string[]> = {
  "eve": ["eve"],
  "ai": ["ai-sdk"],
  "@ai-sdk/openai": ["ai-sdk"],
  "@ai-sdk/anthropic": ["ai-sdk"],
  "@ai-sdk/react": ["ai-sdk"],
  "@ai-sdk/gateway": ["ai-sdk", "ai-gateway"],
  "@vercel/blob": ["vercel-storage"],
  "@vercel/kv": ["vercel-storage"],
  "@vercel/postgres": ["vercel-storage"],
  "@vercel/edge-config": ["vercel-storage"],
  "@vercel/global-config": ["vercel-storage"],
  "workflow": ["workflow"],
  "@vercel/sandbox": ["vercel-sandbox"],
  "flags": ["flags-sdk"],
  "@flags-sdk/vercel": ["flags-sdk", "vercel-flags"],
  "@vercel/flags-core": ["vercel-flags"],
};

const SETUP_ENV_TEMPLATE_FILES: string[] = [
  ".env.example",
  ".env.sample",
  ".env.template",
];

const SETUP_DB_SCRIPT_MARKERS: string[] = [
  "db:push",
  "db:seed",
  "db:migrate",
  "db:generate",
];

const SETUP_AUTH_DEPENDENCIES: Set<string> = new Set([
  "next-auth",
  "@auth/core",
  "better-auth",
]);

const SETUP_RESOURCE_DEPENDENCIES: Record<string, string> = {
  "@neondatabase/serverless": "postgres",
  "drizzle-orm": "postgres",
  "@upstash/redis": "redis",
  "@vercel/blob": "blob",
  "@vercel/edge-config": "global-config",
  "@vercel/global-config": "global-config",
};

const SETUP_MODE_THRESHOLD = 3;
const GREENFIELD_DEFAULT_SKILLS: string[] = [
  "ai-sdk",
  "vercel-cli",
  "env-vars",
];
const GREENFIELD_SETUP_SIGNALS: BootstrapSignals = {
  bootstrapHints: ["greenfield"],
  resourceHints: [],
  setupMode: true,
};
const SESSION_GREENFIELD_KIND = "greenfield";
const SESSION_LIKELY_SKILLS_KIND = "likely-skills";

const log: Logger = createLogger();

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Safely parse package.json from project root.
 */
function readPackageJson(projectRoot: string): PackageJson | null {
  return safeReadJson<PackageJson>(join(projectRoot, "package.json"));
}

// ---------------------------------------------------------------------------
// Exported profilers
// ---------------------------------------------------------------------------

/**
 * Scan a project root and return a deduplicated, sorted list of likely skill slugs.
 */
export function profileProject(projectRoot: string): string[] {
  const skills: Set<string> = new Set();

  // 1. Check marker files
  for (const marker of FILE_MARKERS) {
    if (existsSync(join(projectRoot, marker.file))) {
      for (const s of marker.skills) skills.add(s);
    }
  }

  // 2. Check package.json dependencies
  const pkg: PackageJson | null = readPackageJson(projectRoot);
  if (pkg) {
    const allDeps: Record<string, string> = {
      ...(pkg.dependencies || {}),
      ...(pkg.devDependencies || {}),
    };
    for (const [dep, skillSlugs] of Object.entries(PACKAGE_MARKERS)) {
      if (dep in allDeps) {
        for (const s of skillSlugs) skills.add(s);
      }
    }
  }

  // 3. Check vercel.json keys for more specific skills
  const vercelConfig = safeReadJson<Record<string, unknown>>(join(projectRoot, "vercel.json"));
  if (vercelConfig) {
    if (vercelConfig.rewrites || vercelConfig.redirects || vercelConfig.headers) {
      skills.add("routing-middleware");
    }
    if (vercelConfig.functions) skills.add("vercel-functions");
    if (vercelConfig.services) {
      skills.add("vercel-services");
    }
    if (vercelConfig.daemons) skills.add("daemons");
  }

  return [...skills].sort();
}

/**
 * Detect bootstrap/setup signals and infer likely resource categories.
 */
export function profileBootstrapSignals(projectRoot: string): BootstrapSignals {
  const bootstrapHints: Set<string> = new Set();
  const resourceHints: Set<string> = new Set();

  // Env template signals
  if (SETUP_ENV_TEMPLATE_FILES.some((file: string) => existsSync(join(projectRoot, file)))) {
    bootstrapHints.add("env-example");
  }

  // README* signal
  try {
    const dirents: Dirent[] = readdirSync(projectRoot, { withFileTypes: true });
    if (dirents.some((d: Dirent) => d.isFile() && d.name.toLowerCase().startsWith("readme"))) {
      bootstrapHints.add("readme");
    }
    if (dirents.some((d: Dirent) => d.isFile() && /^drizzle\.config\./i.test(d.name))) {
      bootstrapHints.add("drizzle-config");
      bootstrapHints.add("postgres");
      resourceHints.add("postgres");
    }
  } catch (error) {
    logCaughtError(log, "session-start-profiler:profile-bootstrap-signals-readdir-failed", error, { projectRoot });
  }

  // Prisma schema signal
  if (existsSync(join(projectRoot, "prisma", "schema.prisma"))) {
    bootstrapHints.add("prisma-schema");
    bootstrapHints.add("postgres");
    resourceHints.add("postgres");
  }

  // package.json scripts + dependencies signals
  const pkg: PackageJson | null = readPackageJson(projectRoot);
  if (pkg) {
    const scripts: Record<string, unknown> =
      pkg.scripts && typeof pkg.scripts === "object" ? pkg.scripts : {};
    const scriptEntries: string = Object.entries(scripts)
      .map(([name, cmd]: [string, unknown]) => `${name} ${typeof cmd === "string" ? cmd : ""}`)
      .join("\n");

    for (const marker of SETUP_DB_SCRIPT_MARKERS) {
      if (scriptEntries.includes(marker)) {
        bootstrapHints.add(marker.replace(":", "-"));
      }
    }

    const allDeps: Record<string, string> = {
      ...(pkg.dependencies || {}),
      ...(pkg.devDependencies || {}),
    };

    for (const dep of Object.keys(allDeps)) {
      const resource: string | undefined = SETUP_RESOURCE_DEPENDENCIES[dep];
      if (resource) {
        bootstrapHints.add(resource);
        resourceHints.add(resource);
      }
      if (SETUP_AUTH_DEPENDENCIES.has(dep)) {
        bootstrapHints.add("auth-secret");
      }
    }
  }

  const hints: string[] = [...bootstrapHints].sort();
  const resources: string[] = [...resourceHints].sort();
  return {
    bootstrapHints: hints,
    resourceHints: resources,
    setupMode: hints.length >= SETUP_MODE_THRESHOLD,
  };
}

/**
 * Check if a project root is "greenfield" — only dot-directories and no real
 * source files.  Returns the list of top-level entries if greenfield, or null.
 */
export function checkGreenfield(projectRoot: string): GreenfieldResult | null {
  let dirents: Dirent[];
  try {
    dirents = readdirSync(projectRoot, { withFileTypes: true });
  } catch (error) {
    logCaughtError(log, "session-start-profiler:check-greenfield-readdir-failed", error, { projectRoot });
    return null;
  }

  // Greenfield if every entry is a dot-directory (e.g. .git, .claude) and
  // there are no files at all (dot-files like .mcp.json or .env.local
  // indicate real project config).
  if (dirents.some((d: Dirent) => d.name === ".eve" && d.isDirectory())) {
    return null;
  }

  const hasNonDotDir: boolean = dirents.some((d: Dirent) => !d.name.startsWith("."));
  const hasDotFile: boolean = dirents.some((d: Dirent) => d.name.startsWith(".") && d.isFile());

  if (!hasNonDotDir && !hasDotFile) {
    return { entries: dirents.map((d: Dirent) => d.name).sort() };
  }

  return null;
}

// ---------------------------------------------------------------------------
// Vercel CLI version check
// ---------------------------------------------------------------------------

export interface VercelCliStatus {
  installed: boolean;
  currentVersion?: string;
  latestVersion?: string;
  needsUpdate: boolean;
}

// Subprocess args kept as constants to avoid array literals that confuse the
// validate.ts slug-extraction regex (it scans for `["..."]` patterns).
export const VERCEL_VERSION_ARGS: string[] = "--version".split(" ");
export const NPM_VIEW_ARGS: string[] = "view vercel version".split(" ");
// Built via split to avoid array literal that confuses slug-extraction regex.
const SPAWN_STDIO = "ignore pipe ignore".split(" ") as ("ignore" | "pipe")[];
const EXEC_SYNC_TIMEOUT_MS = 3_000;
const NUMERIC_VERSION_RE = /\d+(?:\.\d+)*/;
const WINDOWS_EXECUTABLE_EXTENSIONS = (process.env.PATHEXT || ".EXE;.CMD;.BAT;.COM")
  .split(";")
  .filter(Boolean);

// Extensions Node can hand to CreateProcess — directly, or through the shell for
// .cmd/.bat. Other PATHEXT entries (.PS1, .PY, .JS, ...) resolve to files
// spawnSync rejects with EFTYPE, so they must never outrank a real executable.
const WINDOWS_SPAWNABLE_EXTENSIONS: string[] = ".EXE;.COM;.CMD;.BAT".split(";");
const WINDOWS_SHELL_SCRIPT_RE = /\.(?:cmd|bat)$/i;

export function getBinaryPathCandidates(
  binaryName: string,
  platform: string = process.platform,
  pathExtensions: string[] = WINDOWS_EXECUTABLE_EXTENSIONS,
): string[] {
  if (platform !== "win32") {
    return [binaryName];
  }

  const hasExecutableExtension = /\.[^./\\]+$/.test(binaryName);
  if (hasExecutableExtension) {
    return [binaryName];
  }

  const isSpawnable = (extension: string): boolean =>
    WINDOWS_SPAWNABLE_EXTENSIONS.includes(extension.toUpperCase());
  // The bare name goes last. On Windows an extensionless entry sitting next to a
  // .cmd is npm's POSIX shim — an sh script spawnSync fails on with ENOENT.
  const suffixes = [
    ...pathExtensions.filter(isSpawnable),
    ...pathExtensions.filter((extension: string) => !isSpawnable(extension)),
    "",
  ];
  return suffixes.map((suffix: string) => `${binaryName}${suffix}`);
}

/**
 * Windows batch wrappers cannot be spawned directly: since the fix for
 * CVE-2024-27980, Node rejects .cmd/.bat without `shell: true` (EINVAL).
 */
export function binaryNeedsShell(
  binaryPath: string,
  platform: string = process.platform,
): boolean {
  return platform === "win32" && WINDOWS_SHELL_SCRIPT_RE.test(binaryPath);
}

/**
 * Build the single command string cmd.exe runs for a batch wrapper. The path is
 * quoted because cmd.exe would otherwise split it on spaces (for example
 * `C:\Program Files\nodejs\npm.cmd`). Args are module constants, never user
 * input, so they are appended as-is.
 */
export function buildShellCommand(binaryPath: string, args: string[]): string {
  return [`"${binaryPath}"`, ...args].join(" ");
}

/** Run a resolved binary and return its trimmed stdout. */
function runBinarySync(binaryPath: string, args: string[]): string {
  const options = {
    timeout: EXEC_SYNC_TIMEOUT_MS,
    encoding: "utf-8" as const,
    stdio: SPAWN_STDIO,
    windowsHide: true,
  };
  // A batch wrapper needs a shell. Pass one command string rather than
  // `shell: true` plus an args array, which Node 24 deprecates (DEP0190).
  if (binaryNeedsShell(binaryPath)) {
    return execSync(buildShellCommand(binaryPath, args), options).trim();
  }
  return execFileSync(binaryPath, args, options).trim();
}

export function resolveBinaryFromPath(binaryName: string): string | null {
  try {
    const pathEntries = (process.env.PATH || "").split(delimiter).filter(Boolean);
    for (const pathEntry of pathEntries) {
      for (const candidateName of getBinaryPathCandidates(binaryName)) {
        const candidatePath = join(pathEntry, candidateName);
        try {
          accessSync(candidatePath, fsConstants.X_OK);
          return candidatePath;
        } catch {
          continue;
        }
      }
    }
  } catch (error) {
    logCaughtError(log, "session-start-profiler:binary-resolution-failed", error, {
      binaryName,
    });
    return null;
  }

  log.debug("session-start-profiler:binary-resolution-skipped", {
    binaryName,
    reason: "not-found",
  });
  return null;
}

function parseVersionSegments(version: string): number[] | null {
  const matchedVersion = version.match(NUMERIC_VERSION_RE)?.[0];
  if (!matchedVersion) {
    return null;
  }

  return matchedVersion
    .split(".")
    .map((segment: string) => Number.parseInt(segment, 10));
}

export function compareVersionSegments(leftVersion: string, rightVersion: string): number | null {
  const leftSegments = parseVersionSegments(leftVersion);
  const rightSegments = parseVersionSegments(rightVersion);

  if (!leftSegments || !rightSegments) {
    return null;
  }

  const maxLength = Math.max(leftSegments.length, rightSegments.length);
  for (let index = 0; index < maxLength; index += 1) {
    const leftSegment = leftSegments[index] ?? 0;
    const rightSegment = rightSegments[index] ?? 0;
    if (leftSegment !== rightSegment) {
      return leftSegment - rightSegment;
    }
  }

  return 0;
}

/**
 * Check if Vercel CLI is installed and whether it's up to date.
 * Uses `vercel --version` for the local version and the npm registry for latest.
 * Returns quickly — each subprocess has a tight timeout.
 */
function checkVercelCli(): VercelCliStatus {
  const vercelBinary = resolveBinaryFromPath("vercel");
  if (!vercelBinary) {
    return { installed: false, needsUpdate: false };
  }

  // 1. Check if vercel is installed
  let currentVersion: string | undefined;
  try {
    const raw: string = runBinarySync(vercelBinary, VERCEL_VERSION_ARGS);
    // Output may include extra lines; version is typically last non-empty line
    const lines: string[] = raw.split("\n").map((l: string) => l.trim()).filter(Boolean);
    currentVersion = lines[lines.length - 1];
  } catch (error) {
    logCaughtError(log, "session-start-profiler:vercel-version-check-failed", error, {
      command: vercelBinary,
      args: VERCEL_VERSION_ARGS.join(" "),
    });
    // The binary is on PATH — only the version probe failed. Reporting "not
    // installed" here would tell the user to install a CLI they already have.
    return { installed: true, needsUpdate: false };
  }

  const npmBinary = resolveBinaryFromPath("npm");
  if (!npmBinary) {
    return { installed: true, currentVersion, needsUpdate: false };
  }

  // 2. Fetch latest version from npm registry
  let latestVersion: string | undefined;
  try {
    latestVersion = runBinarySync(npmBinary, NPM_VIEW_ARGS);
  } catch (error) {
    logCaughtError(log, "session-start-profiler:npm-latest-version-check-failed", error, {
      command: npmBinary,
      args: NPM_VIEW_ARGS.join(" "),
      currentVersion,
    });
    return { installed: true, currentVersion, needsUpdate: false };
  }

  const versionComparison = currentVersion && latestVersion
    ? compareVersionSegments(currentVersion, latestVersion)
    : null;
  const needsUpdate: boolean = versionComparison === null
    ? !!(currentVersion && latestVersion && currentVersion !== latestVersion)
    : versionComparison < 0;

  return { installed: true, currentVersion, latestVersion, needsUpdate };
}

// ---------------------------------------------------------------------------
// Main entry point — profile the project and write env vars.
// ---------------------------------------------------------------------------

interface SessionStartInput {
  session_id?: string;
  conversation_id?: string;
  cursor_version?: string;
  workspace_roots?: string[];
  cwd?: string;
  [key: string]: unknown;
}

export function parseSessionStartInput(raw: string): SessionStartInput | null {
  try {
    if (!raw.trim()) return null;
    return JSON.parse(raw) as SessionStartInput;
  } catch {
    return null;
  }
}

export function detectSessionStartPlatform(
  input: SessionStartInput | null,
  env: NodeJS.ProcessEnv = process.env,
): HookPlatform {
  if (typeof env.CLAUDE_ENV_FILE === "string" && env.CLAUDE_ENV_FILE.trim() !== "") {
    return "claude-code";
  }

  if (input && ("conversation_id" in input || "cursor_version" in input)) {
    return "cursor";
  }

  return "claude-code";
}

/**
 * Map detect-agent output to the deliberately small set of values approved for
 * plugin telemetry. Custom AI_AGENT values are never forwarded verbatim, and a
 * detected but unapproved agent is distinguishable from no detection.
 */
export function normalizeDetectedAgentHarness(name: string | undefined): AgentHarness {
  if (name === undefined) return "unknown";

  switch (name) {
    case "cursor":
    case "cursor-cli":
      return "cursor";
    case "claude_code":
    case "cowork":
      return "claude-code";
    case "codex_cli":
      return "codex";
    case "github-copilot":
      return "github-copilot";
    case "kimi":
      return "kimi";
    case "grok":
      return "grok";
  }

  // detect-agent returns the AI_AGENT env var verbatim when set, and harnesses
  // that follow the AI_AGENT convention publish `<agent>_<version>_<role>`
  // (Claude Code sets e.g. `claude-code_2-1-259_agent`). Match on the agent
  // segment so those sessions are not misreported as "other".
  const agentSegment = name.toLowerCase().split("_")[0] ?? "";
  if (agentSegment === "claude-code" || agentSegment === "claude" || agentSegment === "cowork") return "claude-code";
  if (agentSegment === "cursor" || agentSegment === "cursor-cli") return "cursor";
  if (agentSegment === "codex" || agentSegment === "codex-cli") return "codex";
  if (agentSegment === "github-copilot" || agentSegment === "copilot") return "github-copilot";
  if (agentSegment === "kimi") return "kimi";
  if (agentSegment === "grok") return "grok";

  return "other";
}

type AgentDetector = () => Promise<AgentResult>;

async function determineAgentWithBundledPackage(): Promise<AgentResult> {
  // detect-agent currently publishes CommonJS. The hook is bundled as a
  // standalone ESM file, so provide Node's require implementation immediately
  // before its lazily bundled module is evaluated. This runs inside
  // detectAgentHarness's failure boundary.
  const hookGlobal = globalThis as typeof globalThis & { require?: NodeRequire };
  hookGlobal.require ??= createRequire(import.meta.url);

  const { determineAgent } = await import("detect-agent");
  return determineAgent();
}

export async function detectAgentHarness(
  input: SessionStartInput | null,
  detector: AgentDetector = determineAgentWithBundledPackage,
): Promise<AgentHarness> {
  // Cursor exposes reliable hook payload fields that detect-agent cannot inspect.
  if (input && ("conversation_id" in input || "cursor_version" in input)) {
    return "cursor";
  }

  try {
    const result = await detector();
    return normalizeDetectedAgentHarness(result.isAgent ? result.agent.name : undefined);
  } catch {
    // Harness detection is best-effort and must never block session startup,
    // the active-session marker, or DAU telemetry.
    return "unknown";
  }
}

export function normalizeSessionStartSessionId(input: SessionStartInput | null): string | null {
  if (!input) return null;

  const sessionId = normalizeInput(input as Record<string, unknown>).sessionId;
  return sessionId || null;
}

export function resolveSessionStartProjectRoot(env: NodeJS.ProcessEnv = process.env): string {
  return env.CLAUDE_PROJECT_ROOT ?? env.CURSOR_PROJECT_DIR ?? process.cwd();
}

function collectBrokenSkillFrontmatterNames(files: string[]): string[] {
  return [...new Set(
    files
      .map((file: string) => file.replaceAll("\\", "/").split("/").at(-2) || "")
      .filter((skill: string) => skill !== ""),
  )].sort();
}

export function logBrokenSkillFrontmatterSummary(
  rootDir: string = pluginRoot(),
  logger: Logger = log,
): string | null {
  if (!logger.isEnabled("summary")) {
    return null;
  }

  try {
    const built = buildSkillMap(join(rootDir, "skills"));
    const brokenSkills = collectBrokenSkillFrontmatterNames(
      built.diagnostics.map((diagnostic) => diagnostic.file),
    );

    if (brokenSkills.length === 0) {
      return null;
    }

    const message = `WARNING: ${brokenSkills.length} skills have broken frontmatter: ${brokenSkills.join(", ")}`;
    logger.summary("session-start-profiler:broken-skill-frontmatter", {
      message,
      brokenSkillCount: brokenSkills.length,
      brokenSkills,
    });
    return message;
  } catch (error) {
    logCaughtError(logger, "session-start-profiler:broken-skill-frontmatter-check-failed", error, {
      rootDir,
    });
    return null;
  }
}

export function buildSessionStartProfilerEnvVars(args: {
  greenfield: boolean;
  likelySkills: string[];
  setupSignals: BootstrapSignals;
}): Record<string, string> {
  const envVars: Record<string, string> = {};

  if (args.greenfield) {
    envVars.VERCEL_PLUGIN_GREENFIELD = "true";
  }
  if (args.likelySkills.length > 0) {
    envVars.VERCEL_PLUGIN_LIKELY_SKILLS = args.likelySkills.join(",");
  }
  if (args.setupSignals.bootstrapHints.length > 0) {
    envVars.VERCEL_PLUGIN_BOOTSTRAP_HINTS = args.setupSignals.bootstrapHints.join(",");
  }
  if (args.setupSignals.resourceHints.length > 0) {
    envVars.VERCEL_PLUGIN_RESOURCE_HINTS = args.setupSignals.resourceHints.join(",");
  }
  if (args.setupSignals.setupMode) {
    envVars.VERCEL_PLUGIN_SETUP_MODE = "1";
  }

  return envVars;
}

export function buildSessionStartProfilerUserMessages(
  greenfield: GreenfieldResult | null,
  cliStatus: VercelCliStatus,
): string[] {
  const messages: string[] = [];

  if (greenfield) {
    messages.push(
      "This is a greenfield project. Skip exploration — there is no existing code to discover. Start executing immediately.",
    );
  }

  if (!cliStatus.installed) {
    messages.push(
      [
        "IMPORTANT: The Vercel CLI is not installed.",
        "Strongly recommend the user install it with `npm i -g vercel` to unlock agentic features like `vercel env pull`, `vercel deploy`, and `vercel logs`.",
      ].join("\n"),
    );
  } else if (cliStatus.needsUpdate) {
    messages.push(
      [
        `IMPORTANT: The Vercel CLI is outdated (${cliStatus.currentVersion} → ${cliStatus.latestVersion}).`,
        "Strongly recommend the user upgrade with `npm i -g vercel@latest` or `pnpm add -g vercel@latest` for best compatibility.",
        "The latest version includes significant agentic features and improvements that will greatly enhance their development experience.",
      ].join("\n"),
    );
  }

  return messages;
}

export function formatSessionStartProfilerCursorOutput(
  envVars: Record<string, string>,
  userMessages: string[],
): string {
  const additionalContext = userMessages.join("\n\n");
  return JSON.stringify(formatOutput("cursor", {
    additionalContext: additionalContext || undefined,
    env: envVars,
  }));
}

async function main(): Promise<void> {
  const hookInput = parseSessionStartInput(readFileSync(0, "utf8"));
  const platform = detectSessionStartPlatform(hookInput);
  const agentHarness = await detectAgentHarness(hookInput);
  const sessionId = normalizeSessionStartSessionId(hookInput);
  const projectRoot = resolveSessionStartProjectRoot();
  refreshActiveSessionMarker();

  // Later hooks (skill telemetry) tag their events with this harness.
  if (sessionId && isDauTelemetryEnabled()) {
    writeSessionAgentHarness(sessionId, agentHarness);
  }

  // Greenfield check — seed defaults and skip repository exploration.
  const greenfield: GreenfieldResult | null = checkGreenfield(projectRoot);
  const shouldActivate = greenfield !== null || !existsSync(projectRoot) || hasSessionStartActivationMarkers(projectRoot);

  if (!shouldActivate) {
    log.debug("session-start-profiler:skipped-non-vercel-project", {
      projectRoot,
      reason: "non-empty-without-vercel-markers",
    });

    if (sessionId) {
      writeSessionFile(sessionId, SESSION_GREENFIELD_KIND, "");
      writeSessionFile(sessionId, SESSION_LIKELY_SKILLS_KIND, "");
    }

    if (platform === "cursor") {
      process.stdout.write(JSON.stringify(formatOutput("cursor", {})));
    }

    await trackDauActiveToday(new Date(), { agentHarness }).catch(() => {});
    process.exit(0);
  }

  logBrokenSkillFrontmatterSummary();

  // Vercel CLI version check
  const cliStatus: VercelCliStatus = checkVercelCli();
  const userMessages = buildSessionStartProfilerUserMessages(greenfield, cliStatus);

  const likelySkills: string[] = greenfield
    ? GREENFIELD_DEFAULT_SKILLS
    : profileProject(projectRoot);

  const setupSignals: BootstrapSignals = greenfield
    ? GREENFIELD_SETUP_SIGNALS
    : profileBootstrapSignals(projectRoot);
  const greenfieldValue = greenfield ? "true" : "";
  const likelySkillsValue = likelySkills.join(",");

  const envVars = buildSessionStartProfilerEnvVars({
    greenfield: greenfield !== null,
    likelySkills,
    setupSignals,
  });
  const cursorOutput = platform === "cursor"
    ? formatSessionStartProfilerCursorOutput(envVars, userMessages)
    : null;

  if (sessionId) {
    writeSessionFile(sessionId, SESSION_GREENFIELD_KIND, greenfieldValue);
    writeSessionFile(sessionId, SESSION_LIKELY_SKILLS_KIND, likelySkillsValue);
  }

  try {
    if (platform === "claude-code") {
      for (const [key, value] of Object.entries(envVars)) {
        if (key === "VERCEL_PLUGIN_GREENFIELD" || key === "VERCEL_PLUGIN_LIKELY_SKILLS") {
          continue;
        }
        setSessionEnv(platform, key, value);
      }
    }
  } catch (error) {
    logCaughtError(log, "session-start-profiler:append-env-export-failed", error, {
      platform,
      projectRoot,
      envVarCount: Object.keys(envVars).length,
    });
  }

  const additionalContext = userMessages.join("\n\n");
  if (platform === "claude-code" && additionalContext) {
    process.stdout.write(`${additionalContext}\n\n`);
  }

  // DAU phone-home — enabled by default unless VERCEL_PLUGIN_TELEMETRY=off
  await trackDauActiveToday(new Date(), { agentHarness }).catch(() => {});

  if (cursorOutput) {
    process.stdout.write(cursorOutput);
  }

  process.exit(0);
}

const SESSION_START_PROFILER_ENTRYPOINT = fileURLToPath(import.meta.url);
const isSessionStartProfilerEntrypoint = process.argv[1]
  ? resolve(process.argv[1]) === SESSION_START_PROFILER_ENTRYPOINT
  : false;

if (isSessionStartProfilerEntrypoint) {
  main();
}
