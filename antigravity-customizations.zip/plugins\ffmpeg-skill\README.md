# FFmpeg Skill Plugin

Local FFmpeg video and audio editing for Antigravity, packaged from [kajisho5/ffmpeg-skill](https://github.com/kajisho5/ffmpeg-skill) (`v3.13.2`).

## Included

- **Skill**: `ffmpeg-skill` (`skills/ffmpeg-skill/SKILL.md` + 42 Python FFmpeg tools, templates, and references)
- **MCP Server**: `ffmpeg-skill` configured with `FFMPEG_SKILL_MCP_FULL=1` to expose all 42 tools
